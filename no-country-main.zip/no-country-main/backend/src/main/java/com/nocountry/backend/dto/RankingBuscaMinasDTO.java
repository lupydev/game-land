package com.nocountry.backend.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RankingBuscaMinasDTO {
    private Long id;
    private String gamers;
    private Long averageBuscaMinas;
}
